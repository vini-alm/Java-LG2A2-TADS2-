package lista2_Vinicius_Almeida_Soares;

public enum TipoTransacao {
	
	GANHO, PERCA;
	
}