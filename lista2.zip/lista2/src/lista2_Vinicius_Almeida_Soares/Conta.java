package lista2_Vinicius_Almeida_Soares;
import java.math.*;
import java.util.List;
import java.util.ArrayList;


public class Conta {

	private String nome;
	private BigDecimal saldo;
	private List<extrato> extratos;
	
	
	public Conta(String nome) {
		this.nome = nome;
		saldo = new BigDecimal("0.00");
		extratos = new ArrayList<>();
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public BigDecimal getSaldo() {
		return saldo;
	}
	
	public void addExtrato(extrato ext) {		
		extratos.add(ext);						
		
		if(ext.getTipo() == TipoTransacao.GANHO) {	
			saldo = saldo.add(ext.getValor());
		}
		else {
			saldo = saldo.subtract(ext.getValor());
		}
			
	}

	public void imprimeTransacao() {
		
		System.out.println("Nome: " + nome + " Saldo: R$" + saldo);
		System.out.println("\nExtrato");	
		for(extrato ext: extratos) {
			System.out.println(ext);
		}
		
	}

}
