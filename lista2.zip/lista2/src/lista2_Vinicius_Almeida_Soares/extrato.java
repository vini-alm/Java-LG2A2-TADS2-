package lista2_Vinicius_Almeida_Soares;
import java.time.LocalDate;
import java.math.*;

public class extrato {

	private LocalDate dia;
	private TipoTransacao tipo;
	private String descricao;
	private BigDecimal valor;
	
	
	public extrato(LocalDate dia, BigDecimal valor, String descricao, TipoTransacao tipo) {
		
		this.dia = dia;
		this.valor = valor;
		this.descricao = descricao;
		this.tipo = tipo;
		
	}

	public LocalDate getdia() {
		return dia;
	}

	public void setDia(LocalDate dia) {
		this.dia = dia;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public TipoTransacao getTipo() {
		return tipo;
	}

	public void setTipo(TipoTransacao tipo) {

		this.tipo = tipo;
	}


	
	public String toString() {
		return "\n" + dia + "  R$" + valor + "  descricao: " + descricao + "  tipo: " + tipo;
	}
	
	
}
