package lista2_Vinicius_Almeida_Soares;
import java.time.LocalDate;
import java.math.*;


public class Main {

	public static void main(String[] args) {

		Conta continha = new Conta ("Vinicius");
		
		
		LocalDate dia1 = LocalDate.now(); 						
		BigDecimal valor1 = new BigDecimal("2278.00");						
		String descricao1 = "Pagamento";										
		TipoTransacao tipo1 = TipoTransacao.GANHO; 						
		
		extrato extr1 = new extrato(dia1, valor1, descricao1, tipo1);		
		continha.addExtrato(extr1);											
		

		
		
		
		LocalDate dia2 = LocalDate.now();
		BigDecimal valor2 = new BigDecimal("382.57");
		String descricao2 = "Compras mercado";
		TipoTransacao tipo2 = TipoTransacao.PERCA;
		
		extrato extr2 = new extrato(dia2, valor2, descricao2, tipo2);
		continha.addExtrato(extr2);	
		

		continha.imprimeTransacao();													
		

	}

}
