package lista3_Vinicius_Almeida_Soares;

import java.util.ArrayList;
import java.util.List;

public class OrdemDeServico {
	
		private int codigo;
		private Cliente cliente;
		private ArrayList<Servico> servicos = new ArrayList<>();
		private ArrayList<Mecanico> mecanicos = new ArrayList<>();
r
		public OrdemDeServico(int codigo, Cliente cliente) {
			this.codigo = codigo;
			this.cliente = cliente;
		}
		
	
		public void adicionaServico(Servico servico) {
			
		}
		
		public void adicionaMecanico(Mecanico mecanico) {
			
		}
		
		public double calculaValorTotal() {
			return this.codigo;
		}
		
		public boolean possuiServico(int codigo) {
			return false;
		}
		
		public boolean possuiMecanico(String cpf) {
			return false;
		}
}
