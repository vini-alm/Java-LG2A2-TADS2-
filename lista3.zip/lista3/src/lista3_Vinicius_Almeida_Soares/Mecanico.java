package lista3_Vinicius_Almeida_Soares;

public class Mecanico {
	private String especialidade;
	r
	public Mecanico(String espec, String cpf, String nome) {
		this.especialidade = espec;
	}
	
	public String getEspecialidade() {
		return especialidade;
	}

	public void setEspecialidade(String especialidade) {
		this.especialidade = especialidade;
	}
	
	
}

