package lista3_Vinicius_Almeida_Soares;

public class ServicoExecutar {

	public static void main(String[] args) {
		
		Servico serv1 = new Servico(1, "Sofá sujo de catuaba", 100);
		serv1.status();
		
		Servico serv2 = new Servico(2, "Maquina de lavar", 150);
		serv2.status();
		
		Servico serv3 = new Servico(3, "Conserto de teto", 733);
		serv3.status();
		
		Cliente cliente1 = new Cliente("\n40028922", "3123124123", "Gabs\n");
		cliente1.status();
		
		Cliente cliente2 = new Cliente("27967585", "31231233123", "Vinny\n");
		cliente2.status();

		Cliente cliente3 = new Cliente("13025000", "21332133123", "Tuthu\n");
		cliente3.status();
		
	}

}
