package lista3_Vinicius_Almeida_Soares;

import java.util.ArrayList;
import java.util.List;

public class Oficina {
		private ArrayList<OrdemDeServico> ordensServico = new ArrayList<>();
	
		public Oficina() {
			
		}
		
		public void adicionaOS(OrdemDeServico os) {
			
		}
		
		public List<OrdemDeServico> buscaOsServico(int codigo) {
			return ordensServico;
			
		}
		
		public List<OrdemDeServico> buscaOsMecanico(String cpf) {
			return ordensServico;
			
		}
		
		public double calculaFaturamentoTotal() {
			return 0;
			
		}
		
}
