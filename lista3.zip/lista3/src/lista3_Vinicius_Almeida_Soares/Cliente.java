package lista3_Vinicius_Almeida_Soares;

public class Cliente extends Pessoa {
	private String telefone;

	public Cliente(String telefone, String cpf, String nome) {
		super(cpf, nome);
		this.telefone = telefone;
	}
	
	public String getTelefone() {
		return this.telefone;
	}
	
	public void setTelefone(String tel) {
		this.telefone = tel;
	}
	

	public void status() {
		System.out.println(this.telefone);
		System.out.println(super.getCpf());
		System.out.println(super.getNome());
	}
}