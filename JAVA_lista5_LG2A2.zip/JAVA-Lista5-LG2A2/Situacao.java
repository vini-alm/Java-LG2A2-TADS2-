package aulajonasss;

public enum Situacao {
	MATRICULADO, EVADIDO, FORMADO
}
