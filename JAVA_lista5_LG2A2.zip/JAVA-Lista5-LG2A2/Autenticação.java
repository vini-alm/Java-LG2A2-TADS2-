package aulajonasss;

public interface Autentica��o {
	public void login(String user, String senha);
}
